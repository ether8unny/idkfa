
<?php

	class FOO
	{

		private $blnAddPadding;

		public function __construct ()
		{
			$this->blnAddPadding = true;
		}

		public function magic ($arrData = array (), $arrOffsets = array ())
		{
			//print_r ($arrData);

			foreach ($arrData as $i => $strData)
			{
				$arrData[$i] = $this->_prepare ($strData);
			}

			print_r ($arrData);

			/*
			foreach ($arrData[0] as $i => $binString)
			{
				foreach $arrData[1] as $j => $arrOffset)
				{
					$foo = $this->_xor ()
				}
			}
			*/
		}

		private function _prepare ($strData)
		{
			$arrData = str_split (preg_replace ('/\s+/', '', $strData), 1);
			//var_dump ($arrData);

			foreach ($arrData as $strChar)
			{
				$binChar[] = $this->_hextobin ($strChar);
			}

			return $binChar;
		}

		private function _hextobin ($strChar)
		{
			return str_pad (base_convert ($strChar, 16, 2), (($this->blnAddPadding) ? 4 : 0), 0, STR_PAD_LEFT);
		}

		private function _bintohex ($strChar)
		{
			return str_pad (base_convert ($strChar, 2, 16));
		}

		private function _xor ($binData1, $binData2)
		{
			return $binData0 ^ $binData1;
		}
	}

	/*

		array
		(
			array ($strString, $intOffset);
		);

	*/

	$strData0 = '01abcd';
	$strData1 = 'eeeeee';
	$strData2 = 'dddddd';

	$X = new FOO ();
	$X->magic (array ($strData0, $strData1), array (array (0, 0), array (0, 2), array (2, 4)));

	//$X->xor ()

?>