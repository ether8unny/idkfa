
<?php

	$strHex1 = fopen ('test-1.hex', 'rb');
	$strHex2 = fopen ('test-2.hex', 'rb');

	$blnAddPadding = (isset ($argv[1]) && $argv[1] === '0') ? false : true;
	$strBin1 = '';
	$strBin2 = '';
	$strXOR = '';

	while (true !== feof ($strHex1))
	{
		$strChar = trim (fread ($strHex1, 1));
		if (!preg_match ('/[a-fA-F0-9]/', $strChar)) continue;
		$strBin1 .= str_pad (base_convert ($strChar, 16, 2), (($blnAddPadding) ? 4 : 0), 0, STR_PAD_LEFT);
	}

	while (true !== feof ($strHex2))
	{
		$strChar = trim (fread ($strHex2, 1));
		if (!preg_match ('/[a-fA-F0-9]/', $strChar)) continue;
		$strBin2 .= str_pad (base_convert ($strChar, 16, 2), (($blnAddPadding) ? 4 : 0), 0, STR_PAD_LEFT);
	}

	fclose ($strHex1);
	fclose ($strHex2);

	for ($i = 0; $i < strlen ($strBin1); $i ++)
	{
		$strXOR .= (int)($strBin1[$i]) ^ (int)($strBin2[$i]);
	}

	$foo = str_split ($strXOR, 4);

	$strHex = '';

	foreach ($foo as $key => $value)
	{
		$strHex .= base_convert ($value, 2, 16);
	}

	file_put_contents ('gematria', $strHex);

?>